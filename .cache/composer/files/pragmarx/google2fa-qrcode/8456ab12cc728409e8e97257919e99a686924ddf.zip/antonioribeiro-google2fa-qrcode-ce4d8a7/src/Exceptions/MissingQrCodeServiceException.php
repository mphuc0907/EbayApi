<?php

namespace PragmaRX\Google2FAQRCode\Exceptions;

use Exception;

class MissingQrCodeServiceException extends Exception
{
}
