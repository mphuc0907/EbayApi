<?php

declare(strict_types=1);

namespace MongoDB\Laravel\Query;

use Illuminate\Database\Query\Processors\Processor as BaseProcessor;

class Processor extends BaseProcessor
{
}
